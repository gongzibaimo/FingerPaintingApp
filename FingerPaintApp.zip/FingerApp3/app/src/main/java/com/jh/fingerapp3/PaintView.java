package com.jh.fingerapp3;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PaintView extends View implements View.OnTouchListener{
    private final int DEFAULT_BRUSH_SIZE = 30;
    private final int MAX_BRUSH_SIZE = 100;
    private final int MIN_BRUSH_SIZE = 5;
    private final int DEFAULT_COLOR = Color.RED;
    private int mBrushSize;
    private int mBrushColor;
    private Path mPath;
    private Paint mPaint;
    private float mX, mY, oldX, oldY;
    private ArrayList<Path> pathList;
    private ArrayList<Paint> paintList;
    private ArrayList<Path> undoPath = new ArrayList<Path>();
    private List currentStack;

    // constructors
    public PaintView(Context context) {
        super(context);
        currentStack = Collections.synchronizedList(new ArrayList());
        this.initial();
    }

    public PaintView(Context context, AttributeSet attributeSet){
        super(context, attributeSet);
        this.initial();
    }

    public PaintView(Context context, AttributeSet attributeSet, int defineStyleAttribute){
        super(context, attributeSet, defineStyleAttribute);
        this.initial();
    }

    // initialize
    public void initial(){
        this.mBrushSize = DEFAULT_BRUSH_SIZE;
        this.mBrushColor = DEFAULT_COLOR;
        this.pathList = new ArrayList<Path>();
        this.paintList = new ArrayList<Paint>();
        this.mPath = new Path();
        this.initialPaint(false);
        this.mX = this.mY = this.oldY = this.oldX = (float)0.0;
        this.setOnTouchListener(this);
    }

    // add the path
    private void initialPaint(boolean isFill){
        mPaint = new Paint();
        mPath = new Path();
        paintList.add(mPaint);
        pathList.add(mPath);
        mPaint.setColor(mBrushColor);
        if(!isFill){
            mPaint.setStyle(Paint.Style.STROKE);
        }
        mPaint.setStrokeWidth(mBrushSize);

    }

    // undo method that can back to last step edited
    public void undo(){
        //final int length = pathLength();
        int len = pathList.size();
        if(len > 0){
            undoPath.add(pathList.remove(len-1));
            invalidate();
        }
        else{
            System.out.println("The length should be greater than 0!");
        }
    }


    public int getBrushSize(){
        return mBrushSize;
    }

    public int getBrushColor(){
        return mBrushColor;
    }

    public void setBrushColor(int color){
        this.mBrushColor = color;
    }

    // clear method to clear the canvas to the initial point, default brush color and default brush size
    public void clear(){
        this.initial();
        //pathList.clear();
        this.invalidate();
    }

    // method to change the size of the brush
    public void changeBrushSize(int add){
        this.mBrushSize += add;
        this.mBrushSize = Math.max(mBrushSize, MIN_BRUSH_SIZE);
        this.mBrushSize = Math.min(mBrushSize, MAX_BRUSH_SIZE);
    }

    @Override
    protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        for(int j = 0; j <pathList.size(); j++){
            canvas.drawPath(pathList.get(j), paintList.get(j));
        }
    }


    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        mX = motionEvent.getX();
        mY = motionEvent.getY();
        Log.d("Touched:", "(" + mX + ", " + mY + ")");

        switch (motionEvent.getAction()){
            case MotionEvent.ACTION_DOWN:
                this.initialPaint(false);
                this.mPath.moveTo(mX, mY);
                break;
            case MotionEvent.ACTION_MOVE:
                this.mPath.lineTo(mX, mY);
                break;
            case MotionEvent.ACTION_UP:
                this.initialPaint(true);
                if(oldX == mX && oldY == mY){
                    this.mPath.addCircle(mX, mY, mBrushSize, Path.Direction.CW);
                }
                break;
        }
        this.invalidate();
        oldX = mX;
        oldY = mY;
        return true;
    }
}
