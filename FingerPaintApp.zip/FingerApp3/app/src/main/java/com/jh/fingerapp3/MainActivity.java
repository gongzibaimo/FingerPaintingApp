package com.jh.fingerapp3;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private PaintView paintView;
    private Button red_btn, blue_btn, black_btn, green_btn;
    private Button undo_btn, clear_btn, increment_btn, dec_btn;
    private TextView brushSize_tv;
    private static final int INCREMENT_SIZE = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.initial();
    }
// initialize the paint status

    private void initial() {
        red_btn = (Button) findViewById(R.id.red_button);
        blue_btn = (Button) findViewById(R.id.blue_button);
        green_btn = (Button) findViewById(R.id.green_button);
        black_btn = (Button) findViewById(R.id.black_button);
        increment_btn = (Button) findViewById(R.id.increment_btn);
        dec_btn = (Button) findViewById(R.id.decrement_btn);
        undo_btn = (Button) findViewById(R.id.undo_button);
        clear_btn = (Button) findViewById(R.id.clear_button);

        brushSize_tv = (TextView) findViewById(R.id.brush_tv);

        paintView = (PaintView) findViewById(R.id.paintView_view);
        brushSize_tv.setText("Brush Size is " + paintView.getBrushSize());

        red_btn.setOnClickListener(this);
        blue_btn.setOnClickListener(this);
        green_btn.setOnClickListener(this);
        black_btn.setOnClickListener(this);
        increment_btn.setOnClickListener(this);
        dec_btn.setOnClickListener(this);
        undo_btn.setOnClickListener(this);
        clear_btn.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        Button button = (Button) findViewById(view.getId());

        switch (view.getId()) {
            case R.id.red_button:
                paintView.setBrushColor(Color.RED);
                Log.d("You pressed Button ", button.getText() + " .");
                break;
            case R.id.black_button:
                paintView.setBrushColor(Color.BLACK);
                Log.d("You pressed Button ", button.getText() + " .");
                break;
            case R.id.green_button:
                paintView.setBrushColor(Color.GREEN);
                Log.d("You pressed Button ", button.getText() + " .");
                break;
            case R.id.blue_button:
                paintView.setBrushColor(Color.BLUE);
                Log.d("You pressed Button ", button.getText() + " .");
                break;
            case R.id.clear_button:
                paintView.clear();
                brushSize_tv.setText("Brush size now is: " + paintView.getBrushSize());
                Log.d("You pressed Button ", button.getText() + " .");
                break;
            case R.id.undo_button:
                paintView.undo();
                brushSize_tv.setText("Brush size now is: " + paintView.getBrushSize());
                Log.d("You pressed Button ", button.getText() + " .");
                break;
            case R.id.increment_btn:
                paintView.changeBrushSize(+INCREMENT_SIZE);
                Log.d("You pressed Button ", button.getText() + " .");
                brushSize_tv.setText("Brush size now is: " + paintView.getBrushSize());
                break;
            case R.id.decrement_btn:
                paintView.changeBrushSize(-INCREMENT_SIZE);
                brushSize_tv.setText("Brush size now is: " + paintView.getBrushSize());
                Log.d("You pressed Button ", button.getText() + " .");
                break;
        }
    }
}
